"""GATE 2b (v2) -- is the relation linearly decodable from frozen per-frame features?

v1 fit a 26-way template classifier on POOLED, UNSTANDARDISED features with 217 samples and
read "below chance" as "no signal". Below-chance accuracy is what leave-few-out CV produces on
pure noise, and the pooled input is order-blind, so directional pairs were unsolvable by design.

v2 asks the binary question the thesis actually needs, once per antonym pair, on features that
keep temporal order:

    mean           mean over frames                      (order-blind control)
    halves         [mean(first half), mean(second half)] (order-aware)
    delta          [mean, second - first]                (order-aware)
    halves_shuf    'halves' after shuffling frame order  (must collapse to ~'mean' for directional pairs)

Reported: macro AUC over pairs, a within-pair label-permutation null (mean, 95th pct, p-value).
Reading it:
  * halves >> mean on directional pairs  => the encoder keeps temporal relation information
  * halves ~ mean ~ 0.5                  => features do not carry it (try a video-native encoder)
  * mean > 0.5 on directional pairs      => appearance leak (object/scene differs between templates)

    python -m crvad.probes.linear_probe --encoders clip --data runs/ssv2_pairs.pt
Needs >= ~15 clips per template per pair to be meaningful; pairs with < 3 clips are skipped.
"""
from __future__ import annotations

import argparse
import json
import os
from typing import Dict, List

import torch

from .relation_probe import probe_macro, variants
from .ssv2_data import ANTONYM_PAIRS, pair_kind

CACHE = "runs/feats"


def get_frame_feats(encoder: str, data, dev: str, batch: int = 32, frames=None) -> torch.Tensor:
    """(N,T,D) per-frame features, cached. The cache stores the labels it was built for and is
    discarded if they differ (a stale cache silently attached to new labels is a classic bug).

    `frames` (see encoder_bakeoff._select) selects a frame SUBSET; it is part of the cache key
    because first8 / last8 / shuffled are three different feature sets and reusing one for
    another would silently destroy the order comparison this probe exists to make.
    """
    os.makedirs(CACHE, exist_ok=True)
    tag = f"{encoder}_{frames or 'all'}_frames_{data['clips'].shape[0]}x{data['clips'].shape[1]}"
    path = os.path.join(CACHE, f"{tag}.pt")
    if os.path.exists(path):
        c = torch.load(path, weights_only=True)
        if torch.equal(c["label"], data["label"]):
            print(f"  [{encoder}/{frames or 'all'}] cached")
            return c["F"].float()
        print(f"  [{encoder}] cache labels differ from data -> re-encoding")
    from .encoder_bakeoff import encode_frames

    print(f"  [{encoder}/{frames or 'all'}] encoding {len(data['clips'])} clips ...")
    Fr = encode_frames(encoder, data["clips"], dev, batch, frames=frames).cpu()
    torch.save({"F": Fr.half(), "label": data["label"]}, path)
    return Fr.float()


def video_native_variants(encoder: str, data, dev: str, batch: int = 32) -> Dict[str, torch.Tensor]:
    """Order-aware variants for the T=1 (video-native) encoders.

    X-CLIP / ViCLIP collapse frames inside the encoder, so relation_probe.variants() can only
    produce 'mean' -- there is no frame axis in the output to split into halves. That makes
    them untestable for order sensitivity, which is precisely the capability they are supposed
    to have and the reason to prefer them over an image tower.

    So build the comparison at the encoder INPUT instead: run the encoder separately on the
    first half of the clip and the second half.

        first8 / last8   the two halves, each encoded independently  -> concat = 'halves'
        shuffled         frames in random order

    'shuffled' is the control that decides whether the rest means anything. An encoder that is
    genuinely order-sensitive MUST produce a different embedding when the order is destroyed.
    If halves beats mean but shuffled also beats mean, the probe is reading appearance.
    """
    ident = get_frame_feats(encoder, data, dev, batch, frames=None)[:, 0]
    first = get_frame_feats(encoder, data, dev, batch, frames="first")
    last = get_frame_feats(encoder, data, dev, batch, frames="last")
    shuf = get_frame_feats(encoder, data, dev, batch, frames="shuffled")
    a, b = first[:, 0], last[:, 0]
    return {
        "vmean": ident,                                        # whole clip, natural order
        "vhalves": torch.cat([a, b], dim=1),
        "vdelta": torch.cat([a, b - a], dim=1),
        "vshuf": shuf[:, 0],
        # identity vs shuffled: SAME frames, SAME count, only the order differs, so any
        # drop in cosine is attributable to the encoder using frame order and nothing else.
        "order_sensitivity": (ident * shuf[:, 0]).sum(-1),
    }


def pair_feature_sets(X: torch.Tensor, labels: torch.Tensor, captions) -> List[Dict[str, torch.Tensor]]:
    gid = {c: i for i, c in enumerate(captions)}
    out = []
    for a, b in ANTONYM_PAIRS:
        if a in gid and b in gid:
            out.append({"name": f"{a} vs {b}", "kind": pair_kind(a, b),
                        "A": X[labels == gid[a]], "B": X[labels == gid[b]]})
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="runs/ssv2_pairs.pt")
    ap.add_argument("--encoders", nargs="*", default=["clip", "xclip"])
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--n-perm", type=int, default=200)
    ap.add_argument("--out", default="runs/gate2_relation_probe_v2.json")
    a = ap.parse_args()

    data = torch.load(a.data, weights_only=False)
    labels, captions = data["label"], data["captions"]
    n_frames = data["clips"].shape[1]
    print(f"{len(labels)} clips, {len(captions)} templates, {n_frames} frames\n")
    results: Dict[str, Dict] = {}
    for enc in a.encoders:
        print(f"===== {enc} " + "=" * (54 - len(enc)))
        try:
            Fr = get_frame_feats(enc, data, a.device)
        except Exception as e:
            print(f"  SKIPPED: {type(e).__name__}: {e}\n")
            continue

        vs = {}
        sens = None
        if Fr.shape[1] >= 2:
            # per-frame encoder (CLIP): split the frame axis directly
            vs = variants(Fr)
            g = torch.Generator().manual_seed(0)
            perm = torch.stack([torch.randperm(Fr.shape[1], generator=g) for _ in range(len(Fr))])
            vs["halves_shuf"] = variants(torch.gather(Fr, 1, perm[..., None].expand_as(Fr)))["halves"]
        else:
            # T=1 (video-native): no frame axis survives, so run the encoder on frame
            # SUBSETS instead. Needs >=2 frames to split at all.
            if n_frames < 2:
                print("  only 1 frame per clip; cannot build an order-aware probe\n")
                continue
            vv = video_native_variants(enc, data, a.device)
            sens = vv.pop("order_sensitivity")
            vs = vv

        results[enc] = {}
        if sens is not None:
            # Does the encoder respond to frame ORDER at all? If cosine(identity, shuffled)
            # is ~1.0 the model is order-blind and every order-aware score below is appearance.
            m = sens.mean().item()
            print(f"  order sensitivity: cosine(identity, shuffled) = {m:.4f}   "
                  f"({'ORDER-SENSITIVE' if m < 0.999 else 'ORDER-BLIND -> order-aware scores are appearance'})")
            results[enc]["_order_sensitivity_cosine"] = m
        for name, X in vs.items():
            pfs = pair_feature_sets(X, labels, captions)
            r = probe_macro(pfs, n_perm=a.n_perm)
            results[enc][name] = r
            if r.get("n_pairs", 0):
                sig = "  <-- SIGNIFICANT" if r["p_value"] < 0.05 else ""
                print(f"  {name:12s} macro AUC {r['macro_auc']:.3f}  null {r['null_mean']:.3f} "
                      f"(p95 {r['null_p95']:.3f})  p={r['p_value']:.3f}  ({r['n_pairs']} pairs){sig}")
                # Split by WHY the pair is hard. Each group gets its OWN null, because the
                # two have different pair counts and therefore different noise floors.
                for kind in ("directional", "pretend"):
                    sub = probe_macro([p for p in pfs if p["kind"] == kind], n_perm=a.n_perm)
                    results[enc][f"{name}[{kind}]"] = sub
                    if sub.get("n_pairs", 0):
                        k = "  <-- SIGNAL" if sub["p_value"] < 0.05 else ""
                        print(f"    {kind:12s} AUC {sub['macro_auc']:.3f}  null {sub['null_mean']:.3f} "
                              f"(p95 {sub['null_p95']:.3f})  p={sub['p_value']:.3f} "
                              f"({sub['n_pairs']} pairs){k}")
                    else:
                        print(f"    {kind:12s} no usable pairs (need >=3 clips per template)")
            else:
                print(f"  {name:12s} no usable pairs (need >=3 clips per template)")
        print()
    if results:
        os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
        json.dump(results, open(a.out, "w"), indent=2)
        print(f"wrote {a.out}")


if __name__ == "__main__":
    main()
